dreamAlert
==========

a lite jQuery alert plugin, show notice beautiful and simple.    

Demos
----------
here is the [demos](http://dreamcog.com/lab/dreamAlert/demo/demo.html) 

How to use
----------

*Make sure you added the jQuery library.
*Add dreamAlert js file , css file.

    <head>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
        <link rel="stylesheet" href="/dreamAlert/jquery.dreamalert.css" type="text/css" media="screen" />
        <script type="text/javascript" src="/dreamAlert/jquery.dreamalert.js"></script>
    </head>


when you wanna show some infomation to user , you can use the code:

    $.dreamAlert({
      'type'      :   'success',
      'message'   :   'hello,world!'
    });


API and Setting
----------

setting like this:

    $.dreamAlert.set({
      'duration'  :   1000
    })

the option we supports:

*   duration
    >int , 1000 for 1 second.

*   message
    >var , infomation you wanna show. 

*   type
    >var , success | error | loading , 3 different types of infomation

*   position
    >var , center | right , where is the notice showing

*   summary
    >var , the detail infomation shows when the positon set "right".
